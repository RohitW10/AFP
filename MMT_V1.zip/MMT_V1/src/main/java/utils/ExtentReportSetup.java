package utils;

import java.io.File;

import com.aventstack.extentreports.ExtentReports;
import com.aventstack.extentreports.reporter.ExtentSparkReporter;

public class ExtentReportSetup {
    public static ExtentReports setupExtentReport() {
    	File reportDir = new File("Reports/SparkReport");
        reportDir.mkdirs();
        ExtentSparkReporter spark = new ExtentSparkReporter("Reports/SparkReport/Spark.html");
        ExtentReports extent = new ExtentReports();
        extent.attachReporter(spark);
        // Add system information dynamically
        extent.setSystemInfo("OS", System.getProperty("os.name"));
        extent.setSystemInfo("Java Version", System.getProperty("java.version"));
        extent.setSystemInfo("Browser", System.getProperty("browser", "Chrome")); // Assuming browser is set in properties
        extent.setSystemInfo("Environment", "QA");
        extent.setSystemInfo("Tester", System.getProperty("user.name"));
        extent.setSystemInfo("Project", "MyCucumberBDD");
//        System.out.println("ExtentReportSetup initialized with report path: " + spark.getFilePath());
        return extent;
    }
}