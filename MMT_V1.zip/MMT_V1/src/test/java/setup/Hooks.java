package setup;

import java.io.File;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Properties;

import org.apache.commons.io.FileUtils;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebDriverException;

import com.aventstack.extentreports.ExtentReports;
import com.aventstack.extentreports.ExtentTest;
import com.aventstack.extentreports.MediaEntityBuilder;
import factory.DriverFactory;
import io.cucumber.java.After;
import io.cucumber.java.AfterStep;
import io.cucumber.java.Before;
import io.cucumber.java.Scenario;
import utils.ConfigReader;
import utils.ExtentReportSetup;

import org.openqa.selenium.remote.RemoteWebDriver;

public class Hooks {
    public static WebDriver driver;
    public static ExtentReports extent;
    private ExtentTest extentTest; // Instance per scenario

    @Before
    public void setup(Scenario scenario) {
        Properties prop = new ConfigReader().intializeProperties();
        DriverFactory.initializeBrowser(prop.getProperty("browser"));
        driver = DriverFactory.getDriver();
        driver.get(prop.getProperty("url"));
        System.out.println("WebDriver initialized and navigated to: " + prop.getProperty("url"));
        extent = ExtentReportSetup.setupExtentReport();
        extentTest = extent.createTest(scenario.getName()); // Create ExtentTest for this scenario
        System.out.println("ExtentTest created for: " + scenario.getName());
    }

    @AfterStep
    public void takeScreenshot(Scenario scenario) throws IOException {
        driver = DriverFactory.getDriver();
        try {
            if (driver != null && ((RemoteWebDriver) driver).getSessionId() != null) {
                File src = ((TakesScreenshot) driver).getScreenshotAs(OutputType.FILE);
                String scenarioName = scenario.getName().replaceAll(" ", "_");
                String timeStamp = new SimpleDateFormat("ddMMyyyy_HHmmss").format(new Date());
                String stepScreenshotName = scenarioName + "_" + timeStamp + ".png";
                File dest = new File(System.getProperty("user.dir") + "/src/test/resources/screenshots/" + stepScreenshotName);
                dest.getParentFile().mkdirs();
                FileUtils.copyFile(src, dest);
                System.out.println("Screenshot saved to: " + dest.getAbsolutePath());

                // Attach to ExtentTest
                if (extentTest != null) {
                    extentTest.info("Screenshot for step", MediaEntityBuilder.createScreenCaptureFromPath(dest.getAbsolutePath()).build());
                    System.out.println("Screenshot attached to ExtentTest for scenario: " + scenario.getName());
                } else {
                    System.out.println("ExtentTest is null for scenario: " + scenario.getName());
                }

                // Attach to Cucumber scenario
                byte[] screenshot = ((TakesScreenshot) driver).getScreenshotAs(OutputType.BYTES);
                scenario.attach(screenshot, "image/png", stepScreenshotName);
                System.out.println("Screenshot attached to Cucumber scenario: " + scenario.getName() + " with name: " + stepScreenshotName);

                if (dest.exists()) {
                    System.out.println("Screenshot file exists at: " + dest.getAbsolutePath());
                } else {
                    System.out.println("Screenshot file NOT found at: " + dest.getAbsolutePath());
                }
            }
        } catch (WebDriverException | IOException e) {
            System.out.println("Skipped screenshot due to WebDriver issue: " + e.getMessage());
        }
    }

    @After
    public void tearDown() {
        if (extent != null) {
            extent.flush();
            System.out.println("ExtentReports flushed");
        }
        DriverFactory.quitDriver();
    }
}