package setup;

import org.testng.ITestContext;
import org.testng.ITestListener;
import org.testng.ITestResult;

import com.aventstack.extentreports.ExtentTest;

public class ExtentTestListener implements ITestListener {
    @Override
    public void onTestStart(ITestResult result) {
        ExtentTest test = (ExtentTest) result.getTestContext().getAttribute("extentTest");
        if (test != null) {
            Hooks.setExtentTest(test);
        }
    }

    @Override
    public void onTestSuccess(ITestResult result) {
        // No action needed
    }

    @Override
    public void onTestFailure(ITestResult result) {
        // No action needed
    }

    @Override
    public void onTestSkipped(ITestResult result) {
        // No action needed
    }

    @Override
    public void onTestFailedButWithinSuccessPercentage(ITestResult result) {
        // No action needed
    }

    @Override
    public void onStart(ITestContext context) {
        // No action needed
    }

    @Override
    public void onFinish(ITestContext context) {
        // No action needed
    }
}
